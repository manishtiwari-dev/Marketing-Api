<?php

namespace Modules\Marketing\Services;

use App\Helper\ApiHelper;

class MailConfiger
{
    public static function  update_mail_config() {
        
        if (ApiHelper::getKeySetVal('mail_driver') == 'smtp') {
            //Set the data in an array variable from settings table
            $mailConfig = [
                'transport' => 'smtp',
                'host' => ApiHelper::getKeySetVal('smtp_host_server'),
                'port' => ApiHelper::getKeySetVal('smtp_port'),
                'encryption' => ApiHelper::getKeySetVal('smtp_encryption'),
                'username' => ApiHelper::getKeySetVal('smtp_username'),
                'password' => ApiHelper::getKeySetVal('smtp_password'),
                'timeout' => null
            ];

            //To set configuration values at runtime, pass an array to the config helper
            config(['mail.mailers.smtp' => $mailConfig]);
            config(['mail.default' => 'smtp']);
        } 
        else {
            config(['mail.default' => 'sendmail']);
        }
    }
}
