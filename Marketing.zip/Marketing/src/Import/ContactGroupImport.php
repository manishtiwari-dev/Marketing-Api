<?php

namespace Modules\Marketing\Import;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Illuminate\Support\Facades\Validator;
use ApiHelper;
Use Request;
use Modules\Marketing\Models\ContactToGroup;
use Modules\Marketing\Models\ContactGroup;
use Modules\Marketing\Models\MarketingContact;
use App\Models\Country;
use Exception;
use Illuminate\Support\Facades\Storage;


class ContactGroupImport implements ToModel, WithHeadingRow
{
    // use Importable, SkipsFailures;

    public function __construct($contact_group) 
    {
        $this->contact_group = $contact_group;
    }
        
    // public function rules(): array
    // {
    //     return [
    //         'contact_email' => [
    //             'required',
    //             'string',
    //         ],
    //     ];
    // }

    // public function uniqueBy()
    // {
    //     return 'contact_email';
    // }

    // public function chunkSize(): int
    // {
    //     return 1000;
    // }

    public $counter=0;

    public function model(array $row)
    {   
        $Contact='';

      try{
            $countryID=1;
       
            if(!empty($row['country_name'])){
                $country= Country::where('countries_name' , $row['country_name'])->first();
                if(!empty($country)){
                    $countryID=$country->countries_id;
                }
            }

            $EmailExist=MarketingContact::where('contact_email',$row['contact_email'])->first();

            if(empty($EmailExist)){
                
                $contact_groups= MarketingContact::create([
                        'contact_name'   => $row['contact_name'],
                        'contact_email'   => $row['contact_email'],
                        'company'     => $row['company'],
                        'website'       => $row['website'],
                        'countries_id'     =>$countryID,
                        'phone' => $row['phone'],
                        'address' => $row['address'],
                        'favourites'    => 0,
                        'blocked'       => 0,
                        'trashed'       => 0,
                    ]);

                if (!empty($contact_groups)) {
                    $Contact=ContactToGroup::create([
                        'group_id' =>  (int)$this->contact_group,
                        'contact_id' => $contact_groups->id,
                    ]);
                }
                
                // $this->counter++;

                // if(!empty($Contact)){
                //   return [$Contact,'count'=>$this->counter];        
                // }
                // else{
                //   return [NULL,'count'=>$this->counter];
                // }
            }
      }
      catch(Exception $e)
      {
         return $e->getMessage();
      }
      // return [NULL,'count'=>$this->counter];
    }
}