<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

use Modules\Marketing\Http\Controllers\NewsletterController;
use Modules\Marketing\Http\Controllers\MarketingTemplateController;
use Modules\Marketing\Http\Controllers\MarketingCampaignController;
use Modules\Marketing\Http\Controllers\MarketingContactGroupController;
use Modules\Marketing\Http\Controllers\ContactListController;
use Modules\Marketing\Http\Controllers\SenderMailController;



/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::group(['middleware' => ['ApiTokenCheck'],'prefix'=>"api/"], function() {

    Route::group(['prefix'=>'senderemail'], function(){
        Route::post('/', [SenderMailController::class,'index']);
        Route::post('/store', [SenderMailController::class,'store']);
        Route::post('/sortOrder', [SenderMailController::class,'sortOrder']);
        Route::post('/change-status', [SenderMailController::class,'ChangeStatus']);
        Route::post('/edit', [SenderMailController::class,'edit']);
        Route::post('/update', [SenderMailController::class,'update']);
        Route::post('/delete', [SenderMailController::class,'destroy']);
    });


    //Web News Letter Prefix
    Route::group(['prefix'=>'newsletter'], function(){
        Route::post('/', [NewsletterController::class,'index']);
        Route::post('/store', [NewsletterController::class,'store']);
        Route::post('/edit', [NewsletterController::class,'edit']);
        Route::post('/update', [NewsletterController::class,'update']);
        Route::post('/destroy', [NewsletterController::class,'destroy']);
        Route::post('/changeStatus', [NewsletterController::class,'changeStatus']);
        Route::post('/ImportFile', [NewsletterController::class,'import_file']);
    }); 
    //end News letter prefix  


    //Marketing Templates API
    Route::group(['prefix' => 'marketing-template'], function() {
        Route::post('/', [MarketingTemplateController::class,'index']);
        Route::post('/store', [MarketingTemplateController::class,'store']);
        Route::post('/edit', [MarketingTemplateController::class,'edit']);
        Route::post('/update', [MarketingTemplateController::class,'update']);
        Route::post('/destroy', [MarketingTemplateController::class,'destroy']);
        Route::post('/changeStatus', [MarketingTemplateController::class,'changeStatus']);
    });
    //End Marketing Templates API


     //Marketing Compaign API
     Route::group(['prefix' => 'campaign'], function() {

        Route::post('/', [MarketingCampaignController::class,'index']);
        Route::post('/create', [MarketingCampaignController::class,'create']);
        Route::post('/store', [MarketingCampaignController::class,'store']);                
        Route::post('/edit', [MarketingCampaignController::class,'edit']);
        Route::post('/update', [MarketingCampaignController::class,'update']);
        Route::post('/delete', [MarketingCampaignController::class,'destroy']);
        Route::post('/view', [MarketingCampaignController::class,'view']);
        Route::post('/change-status', [MarketingCampaignController::class,'changeStatus']);
        Route::post('/send-email', [MarketingCampaignController::class,'sendCampaignMail']);


    });
    //End Marketing Compaign  API

    //Marketing Contact group API
    Route::group(['prefix' => 'contact-group'], function() {
        Route::post('/', [MarketingContactGroupController::class,'index']);
        Route::post('/view', [MarketingContactGroupController::class,'list']);
        Route::post('/store', [MarketingContactGroupController::class,'store']);
        Route::post('/edit', [MarketingContactGroupController::class,'edit']);
        Route::post('/update', [MarketingContactGroupController::class,'update']);
        Route::post('/change-status', [MarketingContactGroupController::class,'changeStatus']);
        Route::post('/destroy', [MarketingContactGroupController::class,'destroy']);
        Route::post('/contact-import', [MarketingContactGroupController::class,'contactImport']);
        Route::post('/contact-import-process', [MarketingContactGroupController::class,'contactImportUpload']);

    });
    //End Marketing  API


    //Marketing Contact lists API
    Route::group(['prefix' => 'contact'], function() {
     
        Route::post('/marketing-source-contacts', [ContactListController::class,'sourceContactList']);

        Route::post('/create', [ContactListController::class,'create']);
        Route::post('/store', [ContactListController::class,'store']);
        Route::post('/import_file', [ContactListController::class,'import_file']);
        Route::post('/edit', [ContactListController::class,'edit']);
        Route::post('/update', [ContactListController::class,'update']);
        Route::post('/change-status', [ContactListController::class,'changeStatus']);
        Route::post('/delete', [ContactListController::class,'destroy']);
    });
    //End Marketing  API
   
});

