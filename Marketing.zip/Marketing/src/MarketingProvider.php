<?php

namespace Modules\Marketing;

use Illuminate\Support\ServiceProvider;
use Modules\Marketing\Console\Commands\SendCampaignCron;

class MarketingProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this->loadRoutesFrom(__DIR__.'/routes/api.php');
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        $this->loadViewsFrom(__DIR__.'/resources/views', 'Marketing');

        if ($this->app->runningInConsole()) {
            $this->commands([
                SendCampaignCron::class
            ]);
        }
    }
}
