<?php

namespace Modules\Marketing\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use ApiHelper;
use Modules\Marketing\Models\MarketingTemplate;
use App\Models\UserBusiness;
use DateTime;


class MarketingTemplateController extends Controller
{
    public $page = 'template_list';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pageremove = 'remove';
    public $pageupdate = 'update';


    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;


        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }
        $system_default = [];

        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? (int)$request->perPage : ApiHelper::perPageItem();
        $search = $request->search;
        $sortBy = $request->sortBy;
        $ASCTYPE = $request->orderBY;

        /*Fetching template data*/
        $data_query = MarketingTemplate::query();

        /*Checking if search data is not empty*/
        if ($request->has('search')) {
            if ($request->search != NULL) {
                $data_query = $data_query->where("subject", "LIKE", "%{$search}%");
            }
        }

        // Add Date Filter 

        // if(empty($request->search)){
        /* Add Start Date Filter  */
        if ($request->has('start_date')) {
            if ($request->start_date != NULL) {
                $myDateTime = DateTime::createFromFormat('Y-m-d', $request->start_date);
                $start_date = $myDateTime->format('Y-m-d');

                $data_query = $data_query->whereDate('created_at', '>=', $start_date);
            }
        }

        /* Add End Date Filter  */
        if ($request->has('end_date')) {
            if ($request->end_date != NULL) {
                $myDateTime = DateTime::createFromFormat('Y-m-d', $request->end_date);
                $end_date = $myDateTime->format('Y-m-d');

                $data_query = $data_query->whereDate('created_at', '<=', $end_date);
            }
        }
        // }

        /* order by sorting */
        if (!empty($sortBy) && !empty($ASCTYPE)) {
            $data_query = $data_query->orderBy($sortBy, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('id', 'DESC');
        }

        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;
        $data_count = $data_query->count();
        $data_list = $data_query->skip($skip)->take($perPage)->get();

        $res = [
            'data' => $data_list,
            'current_page' => $current_page,
            'total_records' => $data_count,
            'total_page' => ceil((int)$data_count / (int)$perPage),
            'per_page' => $perPage,
            'start_date'=>$request->start_date ,
            'end_date'=>$request->end_date ,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }


        $validator = Validator::make(
            $request->all(),
            [
                'subject' => 'required',
            ],
            [
                'subject.required' => 'SUBJECT_REQUIRED',
            ]
        );
        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());

        $template_data = $request->only(['subject']);
        $data = MarketingTemplate::create($template_data);

        if ($data)
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_MKT_TEMPLATE_ADD');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_MKT_TEMPLATE_ADD');
    }

    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        $data_list = MarketingTemplate::find($request->id);
        return ApiHelper::JSON_RESPONSE(true, $data_list, '');
    }

    public function update(Request $request)
    {
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }


        $validator = Validator::make(
            $request->all(),
            [
                'subject' => 'required',
                'content' => 'required',
            ],
            [
                'subject.required' => 'SUBJECT_REQUIRED',
                'content.required' => 'CONTENT_REQUIRED',
            ]
        );

        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());

        $template_data = $request->only(['subject', 'content', 'editor_type']);

        $data = MarketingTemplate::where('id', $request->id)->update($template_data);

        $mktdata = MarketingTemplate::where('id', $request->id)->first();

        try {
            if ($request->source == "add")
                return ApiHelper::JSON_RESPONSE(true, $mktdata, 'SUCCESS_MKT_TEMPLATE_ADD');
            else
                return ApiHelper::JSON_RESPONSE(true, $mktdata, 'SUCCESS_MKT_TEMPLATE_UPDATE');
        } catch (Exception $e) {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_MKT_TEMPLATE_UPDATE');
        }
    }


    public function destroy(Request $request)
    {
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageremove)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }


        $status = MarketingTemplate::where('id', $request->id)->delete();
        if ($status) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_MKT_TEMPLATE_DELETE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_MKT_TEMPLATE_DELETE');
        }
    }

    public function changeStatus(Request $request)
    {

        $api_token = $request->api_token;
        $id = $request->id;
        $sub_data = MarketingTemplate::find($id);
        $sub_data->status = ($sub_data->status == 0) ? 1 : 0;
        $sub_data->save();

        return ApiHelper::JSON_RESPONSE(true, $sub_data, 'SUCCESS_STATUS_UPDATE');
    }
}
