<?php

namespace Modules\Marketing\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use ApiHelper;
use Modules\Marketing\Models\MarketingTemplate;
use Modules\Marketing\Models\Campaign;
use Modules\Marketing\Models\SenderEmail;
use Modules\Marketing\Models\ContactGroup;
use Modules\Marketing\Models\CampaignEmail;
use Modules\Marketing\Models\ContactNewsLetter;
use Modules\Marketing\Models\Templates;

use App\Models\UserBusiness;

class SenderEmailController extends Controller
{
    public $page = 'sender_list';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }



        /*Fetching template data*/
        $data_query = SenderEmail::query();
        // dd($form_query);
        /*Checking if search data is not empty*/


        $data_list = $data_query->get();

        $data_list = $data_list->map(function ($data) {

            $data->senderName =  $data->sender_name;
            $data->senderEmail =  $data->sender_email;


            return $data;
        });



        $res = [
            'data' => $data_list,

        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }








    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $campaign_data = $request->only(['sender_name', 'sender_email', 'status']);


        $data = SenderEmail::create($campaign_data);

        if ($data)
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_SENDER_EMAIL_ADD');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_SENDER_EMAIL_ADD');
    }

    public function edit(Request $request)
    {
        // return ApiHelper::JSON_RESPONSE(true,$request->all(),'');
        $api_token = $request->api_token;
        $data_list = SenderEmail::find($request->id);
        return ApiHelper::JSON_RESPONSE(true, $data_list, '');
    }

    public function update(Request $request)
    {

        // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }


        $sender_data = SenderEmail::all();
        $emailDetails = '';
        $id = $request->id;


        foreach ($sender_data as $sendKey => $sendVal) {

            $id = $sendVal->id;
            if (isset($request->{"sender_name_" . $id})) {
                $sender_name = $request->{"sender_name_" . $id};
                $sender_email = $request->{"sender_email_" . $id};

                $emailDetails = SenderEmail::updateOrCreate(
                    ['id' => $id],

                    [
                        'sender_name' => $sender_name,
                        'sender_email' => $sender_email
                    ]
                );
            }
        }

        if ($emailDetails)
            return ApiHelper::JSON_RESPONSE(true, $emailDetails, 'SUCCESS_SENDER_EMAIL_UPDATE');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_SENDER_EMAIL_UPDATE');
    }
}
