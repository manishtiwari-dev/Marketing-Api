<?php

namespace Modules\Marketing\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use ApiHelper;
use App\Helper\ApiHelper as HelperApiHelper;
use App\Models\UserBusiness;
use Modules\Marketing\Models\MarketingTemplate;
use Modules\Marketing\Models\Campaign;
use Modules\Marketing\Models\ContactGroup;
use Modules\Marketing\Models\CampaignEmail;
use Modules\Marketing\Models\ContactNewsLetter;
use Modules\Marketing\Models\ContactToGroup;
use Modules\Marketing\Models\SenderMail;
use Modules\CRM\Models\CRMCustomer;
use Modules\Marketing\Models\MarketingContact;
use Modules\Marketing\Models\NewsLetter;
use Modules\CRM\Models\CRMLead;
use App\Models\TimeZone;
use Carbon\Carbon;
use Modules\Marketing\Jobs\CampaignMailJob;
use Exception;
use Mail;
use DateTime;
use Modules\Marketing\Models\CampaignTracker;
use Modules\WebsiteSetting\Models\Templates;

use Illuminate\Pagination\Paginator;
use Illuminate\Support\Collection;
use Illuminate\Pagination\LengthAwarePaginator;
use Modules\Marketing\Services\MailConfiger;

class MarketingCampaignController extends Controller
{
    public $page = 'campaign';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    public function index(Request $request)
    {

        $api_token = $request->api_token;

        // Validate user page access
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');



        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? (int)$request->perPage : ApiHelper::perPageItem();
        $search = $request->search;


        /*Fetching template data*/
        $data_query = Campaign::with('campaignEmail');

        /*Checking if search data is not empty*/
        if (!empty($search))
        $data_query = $data_query
            ->where("campaign_name", "LIKE", "%{$search}%")->OrWhere("campaign_subject", "LIKE", "%{$search}%");

        /* Add Start Date Filter  */
        if ($request->has('start_date')) {
            if ($request->start_date != NULL) {
                $myDateTime = DateTime::createFromFormat('Y-m-d', $request->start_date);
                $start_date = $myDateTime->format('Y-m-d');
                $data_query = $data_query->whereDate('created_at', '>=', $start_date);
            }
        }

        /* Add End Date Filter  */
        if ($request->has('end_date')) {
            if ($request->end_date != NULL) {
                $myDateTime = DateTime::createFromFormat('Y-m-d', $request->end_date);
                $end_date = $myDateTime->format('Y-m-d');
                $data_query = $data_query->whereDate('created_at', '<=', $end_date);
            }
        }

        /* order by sorting */
        if (!empty($sortBy) && !empty($ASCTYPE)) {

            $data_query = $data_query->orderBy($sortBy, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('id', 'DESC');
        }
        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;
        $data_count = $data_query->count();
        $data_list = $data_query->skip($skip)->take($perPage)->get();

        $data_list=$data_list->map(function($data){

            $senderDeatils=SenderMail::where('id',$data->sender_id)->first();
            if(!empty($senderDeatils))
            $data->sender_name=$senderDeatils->sender_name;
            else
            $data->sender_name='';
           
            return $data;
        });

        $res = [
            'data' => $data_list,
            'current_page' => $current_page,
            'total_records' => $data_count,
            'total_page' => ceil((int)$data_count / (int)$perPage),
            'per_page' => $perPage,
            'start_date'=>$request->start_date,
            'end_date'=>$request->end_date,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function create()
    {
        $tempaltedata = MarketingTemplate::where('status', 1)->get();
        $group_data = ContactGroup::where('status', 1)->get();
        $sender_data = SenderMail::where('status', 1)->get();
        $timezones = TimeZone::all();

        $data = [
            'template_data' => $tempaltedata,
            'group_data' => $group_data,
            'sender_data' => $sender_data,
            'time_zones' => $timezones,
        ];

        if ($data)
            return ApiHelper::JSON_RESPONSE(true, $data, '');
        else
            return ApiHelper::JSON_RESPONSE(false, [], '');
    }

    public function store(Request $request)
    {
        $api_token = $request->api_token;

        // Validate user page access
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $validator = Validator::make($request->all(), [
            'campaign_name' => 'required',
            'campaign_subject' => 'required',
            'template_id' => 'required',
            'sender_id' => 'required',
            'source' => 'required',
            'start_date' => 'required',
            'from_time' => 'required',
            'to_time' => 'required',
            'time_zone' => 'required',
        ], [
            'campaign_name.required' => 'campaign_name_required',
            'campaign_subject.required' => 'campaign_subject_required',
            'template_id.required' => 'select_template',
            'sender_id.required' => 'select_sender',
            'source.required' => 'select_source',

            'start_date.required' => 'start_date_required',
            'from_time.required' => 'from_time_required',
            'to_time.required' => 'to_time_required',
            'time_zone.required' => 'time_zone_required',
        ]);
        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE('validation', [], $validator->messages());

        $campaign_data = $request->only(['campaign_name', 'start_date', 'from_time', 'to_time', 'time_zone', 'campaign_subject', 'description', 'template_id', 'sender_id', 'source']);
        if (!empty($request->group_ids))
            $campaign_data['group_ids'] = implode(",", $request->group_ids);

        $data = Campaign::create($campaign_data);

        if ($request->source ==1) {
            $customer_data = CRMCustomer::where('status', 1)->get();
            if (sizeof($customer_data) > 0) {
                foreach ($customer_data as $customerData) {

                    $existCheck = ContactNewsLetter::where(['source' => 1, 'source_id' => $customerData->customer_id])->first();

                    if (empty($existCheck)) {
                        $conatctNewsLtr = ContactNewsLetter::create([
                            'source' => 1,
                            'source_id' => $customerData->customer_id,
                        ]);
                        $campaignEmail = CampaignEmail::create(
                            [
                                'campaign_id' => $data->id,
                                'newsletter_id' => $conatctNewsLtr->newsletter_id,
                            ]
                        );
                    } else {
                        if ($existCheck->subscription_status == 1 && $existCheck->approval_status == 1 && $existCheck->approval_status == 1) {
                            $campaignEmail = CampaignEmail::create(
                                [
                                    'campaign_id' => $data->id,
                                    'newsletter_id' => $existCheck->newsletter_id,
                                ]
                            );
                        }
                    }
                }
            }
        }
        if ($request->source == 3 && !empty($request->group_ids)) {
            foreach ($request->group_ids as $group_ids) {
                $contact_data = ContactToGroup::where(["group_id" => $group_ids, "status" => 1])->get();
                if (sizeof($contact_data) > 0) {
                    foreach ($contact_data as $contactData) {
                        $existCheck = ContactNewsLetter::where(['source' => 3, 'source_id' => $contactData->contact_id])->first();

                        if (empty($existCheck)) {
                            $conatctNewsLtr = ContactNewsLetter::create([
                                'source' => 3,
                                'source_id' => $contactData->contact_id,
                            ]);

                            $campaignEmail = CampaignEmail::create(
                                [
                                    'campaign_id' => $data->id,
                                    'newsletter_id' => $conatctNewsLtr->newsletter_id,
                                ]
                            );
                        } else {
                            if ($existCheck->subscription_status == 1 && $existCheck->approval_status == 1 && $existCheck->approval_status == 1) {
                                $campaignEmail = CampaignEmail::create(
                                    [
                                        'campaign_id' => $data->id,
                                        'newsletter_id' => $existCheck->newsletter_id,
                                    ]
                                );
                            }
                        }
                    }
                }
            }
        }
        if ($request->source == 2) {
            $lead_data = CRMLead::where('status', 1)->get();
            if (sizeof($lead_data) > 0) {
                foreach ($lead_data as $leadData) {

                    $existCheck = ContactNewsLetter::where(['source' => 2, 'source_id' => $leadData->lead_id])->first();

                    if (empty($existCheck)) {
                        $conatctNewsLtr = ContactNewsLetter::create([
                            'source' => 2,
                            'source_id' => $leadData->lead_id,
                        ]);
                        $campaignEmail = CampaignEmail::create(
                            [
                                'campaign_id' => $data->id,
                                'newsletter_id' => $conatctNewsLtr->newsletter_id,
                            ]
                        );
                    } else {
                        if ($existCheck->subscription_status == 1 && $existCheck->approval_status == 1 && $existCheck->approval_status == 1) {
                            $campaignEmail = CampaignEmail::create(
                                [
                                    'campaign_id' => $data->id,
                                    'newsletter_id' => $existCheck->newsletter_id,
                                ]
                            );
                        }
                    }
                }
            }
        }

        if ($data)
            return ApiHelper::JSON_RESPONSE('true', $data, 'SUCCESS_EMAIL_CAMPAIGN_ADD');
        else
            return ApiHelper::JSON_RESPONSE('false', [], 'ERROR_EMAIL_CAMPAIGN_ADD');
    }

    // Pagination

    public function paginate($items, $perPage=10 , $page = null, $options = [])
    {   
        $perPage = !empty(ApiHelper::perPageItem()) ? (int)ApiHelper::perPageItem(): $perPage;

        $page = $page ?: (Paginator::resolveCurrentPage() ?: 1);
        $items = $items instanceof Collection ? $items : Collection::make($items);
        return new LengthAwarePaginator($items->forPage($page, $perPage), $items->count(), $perPage, $page, $options);
    }

    
    // View Campaign to campaign emails and details
     
    public function view(Request $request)
    {
        $api_token = $request->api_token;
        $perPage = $request->perPage;
        $page = $request->page;
        

        // Validate user page access
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $data = [];
        $customer_data = [];

        $data_list = Campaign::with('mailtemplate')->find($request->id);

        if (empty($data_list))
            return ApiHelper::JSON_RESPONSE(true, [], '');

                   
        $data_list['sender_name'] = SenderMail::where('id', $data_list->sender_id)->first()->sender_name ?? '';
    
        $data['campaign_detail'] =$data_list;
        $data['template_detail'] = MarketingTemplate::where('id', $data_list->template_id)->first();

        $campEmailobj= CampaignEmail::with('campaignewsletter','mailtracker')->where('campaign_id', $data_list->id)->get();
    
      
        if ($data_list->source == 1) {
            if(sizeof($campEmailobj)>0)
            {
              foreach($campEmailobj as $key=>$campEmailData){
                $source_id=$campEmailData->campaignewsletter->source_id ?? '';         
                $crmCustomerData = CRMCustomer::where('customer_id', $source_id)->first();

                if(!empty($crmCustomerData)) {
                    $crmCustomerData['name'] = $crmCustomerData->first_name . ' ' . $crmCustomerData->last_name;
                    $crmCustomerData['email'] = $crmCustomerData->email;
                    $crmCustomerData['news_letter_data']=$campEmailData->campaignewsletter ?? '';
                    $crmCustomerData['tracking_data']=$campEmailData->mailtracker ?? '';
                }
                $customer_data[$key] = $crmCustomerData;
             }
           } 
        }

        if ($data_list->source == 2) {
            if(sizeof($campEmailobj)>0)
            {
                foreach($campEmailobj as $key=>$campEmailData){
                    $source_id=$campEmailData->campaignewsletter->source_id ?? '';  
                    $crmLeadrDatas = CRMLead::where('lead_id', $source_id)->first();

                    if(!empty($crmLeadrData)) {
                        $crmLeadrData['name'] = $crmLeadrData->contact_name ?? '';
                        $crmLeadrData['email'] = $crmLeadrData->contact_email ?? '';
                        $crmLeadrData['news_letter_data']=$campEmailData->campaignewsletter ?? '';
                        $crmLeadrData['tracking_data']=$campEmailData->mailtracker ?? '';
                    }
                    $customer_data[$key] = $crmLeadrDatas;
                 }
           }
        }

        if ($data_list->source ==3) {
            if(sizeof($campEmailobj)>0)
            {   
                foreach($campEmailobj as $key=>$campEmailData){

                    $source_id=$campEmailData->campaignewsletter->source_id ?? '';  

                    $marketingContact = MarketingContact::find($source_id);

                    if(!empty($marketingContact)){
                        $marketingContact['name'] = $marketingContact->contact_name;
                        $marketingContact['email'] = $marketingContact->contact_email;
                        $marketingContact['news_letter_data']=$campEmailData->campaignewsletter ?? '';
                        $marketingContact['tracking_data']=$campEmailData->mailtracker ?? '';

                        $customer_data[$key]= $marketingContact;
                    }    
                }
            }
            
        }

        /*Checking if search data is not empty*/
        // if ($request->has('search')) {
        //     if ($request->search != NULL) {
        //         $data_query = $customer_data->where("group_name", "LIKE", "%{$search}%");
        //     }
        // }

        $customer_data=$this->paginate($customer_data,$perPage,$page);

        $res = [
            'data' => $data,
            'customer_data' => $customer_data,
            // 'current_page' => $current_page,
            // 'total_records' => $user_count,
            // 'cat_name' => $cName,
            // 'total_page' => ceil((int) $user_count / (int) $perPage),
            // 'per_page' => $perPage,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    public function edit(Request $request)
    {
        $data_list = Campaign::find($request->id);

        $data_list['template_data'] = MarketingTemplate::where('status', 1)->get();
        $data_list['sender_data'] = SenderMail::where('status', 1)->get();
        $data_list['group_data'] = ContactGroup::where('status', 1)->get();
        $data_list['time_zone'] = TimeZone::all();

        return ApiHelper::JSON_RESPONSE(true, $data_list, '');
    }

    public function update(Request $request)
    {

        $api_token = $request->api_token;
        // Validate user page access
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');




        $validator = Validator::make($request->all(), [
            'campaign_name' => 'required',
            'campaign_subject' => 'required',
            'template_id' => 'required',
            'sender_id' => 'required',
            'source' => 'required',
            'campaign_id' => 'required',
    
            'start_date' => 'required',
            'from_time' => 'required',
            'to_time' => 'required',
            'time_zone' => 'required',

        ], [
            'campaign_name.required' => 'campaign_name_required',
            'campaign_subject.required' => 'campaign_subject_required',
            'template_id.required' => 'select_template',
            'sender_id.required' => 'select_sender',
            'campaign_id.required' => 'campaign_id_required',

            'start_date.required' => 'start_date_required',
            'from_time.required' => 'from_time_required',
            'to_time.required' => 'to_time_required',
            'time_zone.required' => 'time_zone_required',
        ]);
        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());

        $campaign_data = Campaign::where('id', $request->campaign_id)->first();

        if ($campaign_data->source != $request->source) {
            $campaignEmail = CampaignEmail::where(['campaign_id' => $campaign_data->id, 'status' => 1])->update(
                [
                    'status' => '0',
                ]
            );
        }

        $campaign_data = $request->only(['status','campaign_name', 'start_date', 'from_time', 'to_time', 'time_zone', 'campaign_subject', 'description', 'template_id', 'sender_id', 'source']);

        if (!empty($request->group_ids))
            $campaign_data['group_ids'] = implode(",", $request->group_ids);

        Campaign::where('id', $request->campaign_id)->update($campaign_data);

        $campaignData = Campaign::where('id', $request->campaign_id)->first();


        if ($request->source ==1) {
            $customer_data = CRMCustomer::where('status', 1)->get();
            if (sizeof($customer_data) > 0) {
                foreach ($customer_data as $customerData) {

                    $existCheck = ContactNewsLetter::where(['source' => 1, 'source_id' => $customerData->customer_id])->first();

                    if (empty($existCheck)) {
                        $conatctNewsLtr = ContactNewsLetter::create([
                            'source' => 1,
                            'source_id' => $customerData->customer_id,
                        ]);
                        $campaignEmail = CampaignEmail::create(
                            [
                                'campaign_id' => $campaignData->id,
                                'newsletter_id' => $conatctNewsLtr->newsletter_id,
                            ]
                        );
                    }
                }
            }
        }
        if ($request->source == 3 && !empty($request->group_ids)) {
            foreach ($request->group_ids as $group_ids) {
                $contact_data = ContactToGroup::where(["group_id" => $group_ids, "status" => 1])->get();
                if (sizeof($contact_data) > 0) {
                    foreach ($contact_data as $contactData) {
                        $existCheck = ContactNewsLetter::where(['source' => 3, 'source_id' => $contactData->contact_id])->first();

                        if (empty($existCheck)) {
                            $conatctNewsLtr = ContactNewsLetter::create([
                                'source' => 3,
                                'source_id' => $contactData->contact_id,
                            ]);

                            $campaignEmail = CampaignEmail::create(
                                [
                                    'campaign_id' => $campaignData->id,
                                    'newsletter_id' => $conatctNewsLtr->newsletter_id,
                                ]
                            );
                        }
                    }
                }
            }
        }
        if ($request->source == 2) {
            $lead_data = CRMLead::where('status', 1)->get();
            if (sizeof($lead_data) > 0) {
                foreach ($lead_data as $leadData) {

                    $existCheck = ContactNewsLetter::where(['source' => 2, 'source_id' => $leadData->lead_id])->first();

                    if (empty($existCheck)) {
                        $conatctNewsLtr = ContactNewsLetter::create([
                            'source' => 2,
                            'source_id' => $leadData->lead_id,
                        ]);
                        $campaignEmail = CampaignEmail::create(
                            [
                                'campaign_id' => $campaignData->id,
                                'newsletter_id' => $conatctNewsLtr->newsletter_id,
                            ]
                        );
                    }
                }
            }
        }

        try {
            return ApiHelper::JSON_RESPONSE(true, $campaignData, 'SUCCESS_EMAIL_CAMPAIGN_UPDATE');
        } catch (Exception $e) {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_EMAIL_CAMPAIGN_UPDATE');
        }
    }


    public function destroy(Request $request)
    {
        $campaign_id = $request->id;
        $campaignData = Campaign::find($campaign_id);
        
        $status = '';
        if (!empty($campaignData)) {
            Campaign::where('id', $campaign_id)->delete();
            $newsLetterIds = CampaignEmail::where('campaign_id', $campaign_id)->pluck('newsletter_id');
            CampaignEmail::where('campaign_id', $campaign_id)->delete();
            $status = ContactNewsLetter::whereIn('newsletter_id', $newsLetterIds)->delete();
        }

        if ($status) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_EMAIL_CAMPAIGN_DELETE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_EMAIL_CAMPAIGN_DELETE');
        }
    }

    public function changeStatus(Request $request)
    {
        $api_token = $request->api_token;
        $id = $request->id;
        $sub_data = Campaign::find($id);
        $sub_data->status = ($sub_data->status == 0) ? 1 : 0;
        $sub_data->save();

        return ApiHelper::JSON_RESPONSE(true, $sub_data, 'SUCCESS_STATUS_UPDATE');
    }


    // Send mail

    public static function sendCampaignMail(Request $request) {

        MailConfiger::update_mail_config();
        $data = [];

        $campaign_id = $request->id;
        
        $campaign_data = Campaign::where(['id' => $campaign_id, 'status' => 1])->first();

        if (!empty($campaign_data)) {
            $dt = Carbon::now($campaign_data->time_zone);

            $today_date = $dt->toDateString();
            $current_time = $dt->toTimeString();

      
            // dd($campaign_data->start_date>=$today_date);
            // dd($current_time>=$campaign_data->from_time);
            // dd($current_time<=$campaign_data->to_time);


            if ($campaign_data->start_date >= $today_date && $current_time >= $campaign_data->from_time && $current_time <= $campaign_data->to_time) {
         
                $newsLetterIds = CampaignEmail::where(['campaign_id' => $campaign_data->id, 'status' => 1])->get();
             
                if ($campaign_data->source == 1) {
                    $crmCustomerDatas='';
                    foreach ($newsLetterIds as $key => $news_ltr_id) {
                        $customer_contact_news = ContactNewsLetter::where(['source' => 1, 'subscription_status' => 1, 'approval_status' => 1, 'email_status' => 1, 'newsletter_id' => $news_ltr_id->newsletter_id])->first();
                        
                        if (!empty($customer_contact_news)) {
                            $crmCustomerDatas = CRMCustomer::where('customer_id', $customer_contact_news->source_id)->first();
                            $crmCustomerDatas['name'] = $crmCustomerDatas->first_name . ' ' . $crmCustomerDatas->last_name;
                            $crmCustomerDatas['email'] = $crmCustomerDatas->email;
                            $crmCustomerDatas['camp_email_id'] = $news_ltr_id->id;
                        } else {
                            CampaignEmail::where(['newsletter_id' => $news_ltr_id->newsletter_id, 'campaign_id' => $campaign_data->id])->update(['status'=> 0]);
                        }

                        $data['customer_data'][$key] = $crmCustomerDatas;
                    }
                }
      
                if ($campaign_data->source == 2) {  
             
                    $crmLeadrDatas='';
                    foreach ($newsLetterIds as $key => $news_ltr_id) {
                        $customer_contact_news = ContactNewsLetter::where(['source' => 2, 'subscription_status' => 1, 'approval_status' => 1, 'email_status' => 1, 'newsletter_id' => $news_ltr_id->newsletter_id])->first(); 
                        if (!empty($customer_contact_news)) {
                            $crmLeadrDatas = CRMLead::where('lead_id', $customer_contact_news->source_id)->first();
                            $crmLeadrDatas['name'] = $crmLeadrDatas->contact_name;
                            $crmLeadrDatas['email'] = $crmLeadrDatas->contact_email;
                            $crmLeadrDatas['camp_email_id'] = $news_ltr_id->id;
                        } else {
                            CampaignEmail::where(['newsletter_id' => $news_ltr_id->newsletter_id, 'campaign_id' => $campaign_data->id])->update(['status'=> 0]);
                        }

                        $data['customer_data'][$key] = $crmLeadrDatas;
                    }
                }
 
                if ($campaign_data->source ==3) {
                    $marketingContact='';
                    foreach ($newsLetterIds as $key => $news_ltr_id) {
                        $customer_contact_news = ContactNewsLetter::where(['source' => 3, 'subscription_status' => 1, 'approval_status' => 1, 'email_status' => 1, 'newsletter_id' => $news_ltr_id->newsletter_id])->first();

                        if (!empty($customer_contact_news)) {
                            $marketingContact = MarketingContact::where('contact_id', $customer_contact_news->source_id)->first();
                            $marketingContact['name'] = $marketingContact->contact_name;
                            $marketingContact['email'] = $marketingContact->contact_email;
                            $marketingContact['camp_email_id'] = $news_ltr_id->id;
                        } else {
                            CampaignEmail::where(['newsletter_id' => $news_ltr_id->newsletter_id, 'campaign_id' => $campaign_data->id])->update(['status'=> 0]);
                        }
                        $data['customer_data'][$key] = $marketingContact;
                    }
                }

                $data['template_data'] = MarketingTemplate::where('id', $campaign_data->template_id)->first();
                $data['subject'] = $campaign_data->campaign_subject;
                $data['sender_details'] = SenderMail::where('id', $campaign_data->sender_id)->where('status', 1)->first();
             
                if (!empty($data['sender_details']) && !empty($data['customer_data']) && sizeof($data['customer_data'])>0) {
                    foreach ($data['customer_data'] as $customer_data) {
                        $mail_data = [
                            'sender_name' => $data['sender_details']->sender_name,
                            'sender_email' => $data['sender_details']->sender_email,
                            'subject' => $data['subject'],
                            'content' => $data['template_data']->content,
                            'unsubscription_url' => url()->full(),
                            'customer_data' => $customer_data,
                            'web_base_url' => ApiHelper::getKeyVal('website_url'),
                        ];

                        try {

                            $campEmail = CampaignEmail::where('id', $customer_data->camp_email_id)->first();

                            CampaignTracker::create([
                                'campaign_contact_id' => $customer_data->camp_email_id,
                                'sent_date' => date('Y-m-d'),
                            ]);

                            $newsQuery = ContactNewsLetter::where('newsletter_id', $campEmail->newsletter_id);

                            $newsQuery->increment('newsletter_count');
                            $newsQuery->update([
                                'newsletter_sent_date' => date('Y-m-d'),
                            ]);
                    
                            CampaignMailJob::dispatch($mail_data)->delay(now()->addSeconds(value: 5));
                        } catch (Exception $e) {
                            echo($e->getMessage());
                        }
                    }

                    // Set Campaign Status Inactive After Send All mail

                    Campaign::where('id', $campaign_id)->update([
                        'status' => 2
                    ]);
                }

                return ApiHelper::JSON_RESPONSE(true, $data, '');
            }
        }
    }
}
