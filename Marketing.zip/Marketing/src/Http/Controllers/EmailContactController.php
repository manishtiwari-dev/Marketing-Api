<?php

namespace Modules\Marketing\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use ApiHelper;
use Modules\Marketing\Models\ContactToGroup;
use Modules\Marketing\Models\ContactGroup;
use Modules\Marketing\Models\MarketingContact;
use Modules\Marketing\Models\ContactNewsLetter;
use App\Models\Country;


class EmailContactController extends Controller
{
    public $page = 'contact';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    public function list(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $sortBY = $request->sortBy;
        $ASCTYPE = $request->orderBY;

        $data_list = ContactToGroup::with('group_details', 'contact_details')->where('group_id', $request->id)->orderBy('id', 'DESC')->get();

        $group_name = '';

        if ($request->has('id')) {
            //getting category Name
            $grpName = ContactGroup::where('id', $request->id)->first();
            $group_name = !empty($grpName) ? $grpName->group_name : '';
        }

        $res = [
            'data_list' => $data_list,
            'group_name' => $group_name,
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    public function create()
    {
        $countrydata = Country::all();
        $group_data = ContactGroup::all();
        $data = [
            'country_data' => $countrydata,
            'group_data' => $group_data,
        ];

        if ($data)
            return ApiHelper::JSON_RESPONSE(true, $data, '');
        else
            return ApiHelper::JSON_RESPONSE(false, [], '');
    }

    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        //validation check 
        $validator = Validator::make(
            $request->all(),
            [
                'contact_name' => 'required',
                'contact_email' => 'required|email',
                'countried_id' => 'required',
            ],
            [
                'contact_name.required' => 'CONTACT_NAME_REQUIRED',
                'contact_email.required' => 'CONTACT_EMAIL_REQUIRED',
                'contact_email.email' => 'ENTER_VALID_EMAIL',
                'countried_id.required' => 'COUNTRY_REQUIRED',
            ]
        );
        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());

        $contact_data =  MarketingContact::create([
            'contact_name' => $request->contact_name,
            'contact_email' => $request->contact_email,
            'company' => $request->company,
            'website' => $request->website,
            'countried_id' =>  $request->countried_id,
            'phone' =>  $request->phone,
            'address' => $request->address,

        ]);

        if (!empty($contact_data)) {
            $contact_group = ContactToGroup::create([
                'group_id' => $request->id,
                'contact_id' => $contact_data->id,
            ]);
        }

        $data = [
            'contact_data' => $contact_data,
            'contact_group' => $contact_group,
        ];

        // $contactNews =  ContactNewsLetter::create([
        //     'contact_id' => $contact_data->id
        // ]);

        if ($data)
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_CONTACT_ADD');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_CONTACT_ADD');
    }

    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        $data_list = MarketingContact::with('contact')->where('id', $request->id)->first();

        $countrydata = Country::all();
        $group_data = ContactGroup::all();


        //   return ApiHelper::JSON_RESPONSE(true,$data_list->contact,'');
        if (!empty($data_list->contact))

            $data_list->contact = $data_list->contact->group_id;

        $res = [
            'data_list' => $data_list,
            'countrydata' => $countrydata,
            'group_data' => $group_data,
        ];


        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function update(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        //validation check 
        $validator = Validator::make(
            $request->all(),
            [
                'contact_name' => 'required',
                'contact_email' => 'required|email',
                'countried_id' => 'required',
            ],
            [
                'contact_name.required' => 'CONTACT_NAME_REQUIRED',
                'contact_email.required' => 'CONTACT_EMAIL_REQUIRED',
                'contact_email.email' => 'ENTER_VALID_EMAIL',
                'countried_id.required' => 'COUNTRY_REQUIRED',
            ]
        );
        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());

        $id = $request->id;

        $data = MarketingContact::where('id', $id)->update([
            'contact_name' => $request->contact_name,
            'contact_email' => $request->contact_email,
            'company' => $request->company,
            'website' => $request->website,
            'countried_id' =>  $request->countried_id,
            'phone' =>  $request->phone,
            'address' => $request->address,

        ]);

        $contact_details = MarketingContact::find($id);
        if (!empty($contact_details)) {
            ContactToGroup::updateOrCreate(
                [
                    'contact_id' => $contact_details->id,
                ],
                [
                    'group_id' => $request->group_id,
                ]
            );
        }

        // $contactNews =  ContactNewsLetter::where('contact_id', $contact_details->id)->update([
        //     'contact_id' => $contact_details->id,
        // ]);

        if ($data)
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_CONTACT_UPDATE');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_CONTACT_UPDATE');
    }

    public function changeStatus(Request $request)
    {

        $api_token = $request->api_token;
        $template_id = $request->template_id;
        $sub_data = ContactToGroup::find($template_id);
        $sub_data->status = ($sub_data->status == 0) ? 1 : 0;
        $sub_data->save();

        return ApiHelper::JSON_RESPONSE(true, $sub_data, 'SUCCESS_STATUS_UPDATE');
    }


    public function import_file(Request $request)
    {
        $dataList = ApiHelper::read_csv_data($request->fileInfo, "csv/Contact");
        foreach ($dataList as $key => $value) {

            // $details = $value[0];
            // return ApiHelper::JSON_RESPONSE(true, $details, 'SUCCESS_CONTACT_IMPORTED');

            if (isset($value)) {


                $contact_name = isset($value[0]) ? $value[0] : 0;
                $contact_email = isset($value[1]) ? $value[1] : 0;
                $company = isset($value[2]) ? $value[2] : 0;
                $website = isset($value[3]) ? $value[3] : 0;
                $phone = isset($value[4]) ? $value[4] : 0;
                $address = isset($value[5]) ? $value[5] : 0;

                $newsletter_data =  MarketingContact::where('contact_email', $contact_email)->first();

                if (empty($newsletter_data)) {
                    $data = [
                        'contact_name' => $contact_name,
                        'contact_email' => $contact_email,
                        'company' => $company,
                        'website' => $website,
                        'phone' => $phone,
                        'address' => $address,
                    ];
                    $newsletter = MarketingContact::create($data);


                    $Userdata = [

                        'group_id' => $request->group_id,
                        'contact_id' => $newsletter->id,

                    ];

                    $userCreate = ContactToGroup::create($Userdata);

                    $contactNews = [
                        'contact_id' => $newsletter->id,
                    ];

                    // $contact = ContactNewsLetter::create($contactNews);
                }
            }
        }

        return ApiHelper::JSON_RESPONSE(true, $dataList, 'SUCCESS_CONTACT_IMPORTED');
    }


    public function destroy(Request $request)
    {
        $contact_id = $request->contact_id;
        // $data=[
        //     'contact_id'=>$contact_id,
        // ];
        // return ApiHelper::JSON_RESPONSE(true,$data, 'SUCCESS_CONTACT_DELETE');

        $contactData = MarketingContact::find($contact_id);

        $status = 0;

        if (!empty($contactData)) {
            $status = MarketingContact::where('id', $contact_id)->delete();
        }

        if ($status) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_CONTACT_DELETE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_CONTACT_DELETE');
        }
    }
}
