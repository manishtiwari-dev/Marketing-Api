<?php

namespace Modules\Marketing\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use ApiHelper;
use Exception;
use Modules\Marketing\Models\SenderMail;
use Illuminate\Support\Facades\Validator;
use DateTime;

class SenderMailController extends Controller
{




    public $page = 'sender_list';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';


    public function index(Request $request)
    {   
        
        $api_token = $request->api_token;

        // Validate user page access
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? $request->perPage : 10;
        $search = $request->search;

        $data_query = SenderMail::query();

        // attaching query filter by permission(all, added,owned,both)
        // $data_query = ApiHelper::attach_query_permission_filter($data_query, $api_token, $this->page, $this->pageview);

        // search
        if (!empty($search))
            $data_query = $data_query->where("sender_name", "LIKE", "%{$search}%")->OrWhere("sender_email", "LIKE", "%{$search}%");
        
        
        /* Add Start Date Filter  */

        if ($request->has('start_date')) {
            if ($request->start_date != NULL) {
                $myDateTime = DateTime::createFromFormat('Y-m-d', $request->start_date);
                $start_date = $myDateTime->format('Y-m-d');
                $data_query = $data_query->whereDate('created_at', '>=', $start_date);
            }
        }

        /* Add End Date Filter  */

        if ($request->has('end_date')) {
            if ($request->end_date != NULL) {
                $myDateTime = DateTime::createFromFormat('Y-m-d', $request->end_date);
                $end_date = $myDateTime->format('Y-m-d');
                $data_query = $data_query->whereDate('created_at', '<=', $end_date);
            }
        }

        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;     // apply page logic
        $data_count = $data_query->count(); // get total count
        $data_list = $data_query->skip($skip)->take($perPage)->orderBy('id', 'DESC')->get();

        $data_list = $data_list->map(function ($data) {
            $data->status = ($data->status == 1) ? "1" : "0";
            return $data;
        });

        $res = [
            'data' => $data_list,
            'current_page' => $current_page,
            'total_records' => $data_count,
            'total_page' => ceil((int)$data_count / (int)$perPage),
            'per_page' => $perPage,
            'start_date'=>$request->start_date ,
            'end_date'=>$request->end_date ,
        ];

        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function store(Request $request)
    {
        $api_token = $request->api_token;

        // Validate user page access
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        //validation check 
        $validator = Validator::make(
            $request->all(),
            [
                'sender_name' => 'required',
                'sender_email' => 'required|email',
                'reply_name' => 'required',
                'reply_email' => 'required|email',
            ],
            [
                'sender_name.required' => 'SENDER_NAME_REQUIRED',
                'sender_email.required' => 'SENDER_NAME_REQUIRED',
                'sender_email.email' => 'ENTER_VALID_EMAIL',

                'reply_name.required' => 'REPLY_NAME_REQUIRED',
                'reply_email.required' => 'REPLY_NAME_REQUIRED',
                'reply_email.email' => 'REPLY_VALID_EMAIL',
            ]
        );
        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());

        $mailExist = SenderMail::where('sender_email', $request->sender_email)->first();

        if (!empty($mailExist))
            return ApiHelper::JSON_RESPONSE(false, [], "E-mail already exist");

        $Insert = $request->only(['sender_name', 'sender_email','reply_name', 'reply_email']);

        $res = SenderMail::create($Insert);

        if ($res)
            return ApiHelper::JSON_RESPONSE(true, $res->id, 'SUCCESS_MAIL_SENDER_ADD');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_MAIL_SENDER_ADD');
    }

    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        $data_list = SenderMail::where('id', $request->sender_id)->first();
        return ApiHelper::JSON_RESPONSE(true, $data_list, '');
    }

    public function update(Request $request)
    {
        $api_token = $request->api_token;
        // Validate user page access
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $sender_id = $request->sender_id;
        //validation check 
        $validator = Validator::make(
            $request->all(),
            [
                'sender_name' => 'required',
                'sender_email' => 'required|email',

                'reply_name' => 'required',
                'reply_email' => 'required|email',
            ],
            [
                'sender_name.required' => 'SENDER_NAME_REQUIRED',
                'sender_email.required' => 'SENDER_NAME_REQUIRED',
                'sender_email.email' => 'ENTER_VALID_EMAIL',
                'sender_email.unique' => 'MAIL_ALREADY_REGISTERD',

                'reply_name.required' => 'REPLY_NAME_REQUIRED',
                'reply_email.required' => 'REPLY_NAME_REQUIRED',
                'reply_email.email' => 'REPLY_VALID_EMAIL',
            ]
        );
        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());

        $mailExist = SenderMail::where('sender_email', $request->sender_email)->where('id', '<>', $request->sender_id)->first();

        if (!empty($mailExist))
            return ApiHelper::JSON_RESPONSE(false, [], "E-mail already exist");

        $Insert = $request->only('sender_name', 'sender_email', 'status','reply_name', 'reply_email');

        try {
            $res = SenderMail::where('id', $sender_id)->update($Insert);
            return ApiHelper::JSON_RESPONSE(true, $res, 'SUCCESS_MAIL_SENDER_UPDATE');
        } catch (Exception $e) {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_MAIL_SENDER_UPDATE');
        }
    }

    public function destroy(Request $request)
    {
        $api_token = $request->api_token;
        // Validate user page access
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pagestatus))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');


        $sender_id = $request->sender_id;
        $status = SenderMail::where('id', $sender_id)->delete();
        if ($status) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_MAIL_SENDER_DELETE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_MAIL_SENDER_DELETE');
        }
    }

    public function changeStatus(Request $request)
    {
        $infoData = SenderMail::where('id', $request->sender_id)->first();
        $infoData->status = ($infoData->status == 0) ? 1 : 0;
        $infoData->save();
        return ApiHelper::JSON_RESPONSE(true, $infoData, 'SUCCESS_STATUS_UPDATE');
    }
}
