<?php

namespace Modules\Marketing\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use ApiHelper;
use Modules\Marketing\Models\ContactToGroup;
use Modules\Marketing\Models\ContactGroup;
use Modules\Marketing\Models\MarketingContact;
use Modules\Marketing\Import\ContactGroupImport;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Storage;
use DateTime;
use App\Models\UserBusiness;


class MarketingContactGroupController extends Controller
{
    public $page = 'contact';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';



    //Show Contact Groups 

    public function index(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');



        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? (int)$request->perPage : ApiHelper::perPageItem();
        $search = $request->search;
        $sortBy = $request->sortBy;
        $ASCTYPE = $request->orderBY;

        $data_query = ContactGroup::query();

        /*Checking if search data is not empty*/
        if (!empty($search))
            $data_query = $data_query->where("group_name", "LIKE", "%{$search}%");

        /*Checking if search data is not empty*/
        if ($request->has('search')) {
            if ($request->search != NULL) {
                $data_query = $data_query->where("group_name", "LIKE", "%{$search}%");
            }
        }

        // Add Date Filter 

        // if(empty($request->search)){
        /* Add Start Date Filter  */
        if ($request->has('start_date')) {
            if ($request->start_date != NULL) {
                $myDateTime = DateTime::createFromFormat('Y-m-d', $request->start_date);
                $start_date = $myDateTime->format('Y-m-d');

                $data_query = $data_query->whereDate('created_at', '>=', $start_date);
            }
        }

        /* Add End Date Filter  */
        if ($request->has('end_date')) {
            if ($request->end_date != NULL) {
                $myDateTime = DateTime::createFromFormat('Y-m-d', $request->end_date);
                $end_date = $myDateTime->format('Y-m-d');

                $data_query = $data_query->whereDate('created_at', '<=', $end_date);
            }
        }
        // }


        /* order by sorting */
        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy('id', 'DESC');
        }

        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;
        $data_count = $data_query->count();
        $data_list = $data_query->skip($skip)->take($perPage)->get();

        // $data_list = $data_query->get();


        $res = [
            'data_list' => $data_list,
            'current_page' => $current_page,
            'total_records' => $data_count,
            'total_page' => ceil((int)$data_count / (int)$perPage),
            'per_page' => $perPage,
            'start_date'=>$request->start_date ,
            'end_date'=>$request->end_date ,
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    // Contact group to contact list

    public function list(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $data_query = ContactToGroup::with('group_details', 'contact_details')->where('group_id', $request->group_id)->orderBy('id', 'DESC');

        $group_name = '';

        if ($request->has('group_id')) {
            //getting category Name
            $grpName = ContactGroup::where('id', $request->group_id)->first();
            $group_name = !empty($grpName) ? $grpName->group_name : '';
        }

        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty(ApiHelper::perPageItem()) ? ApiHelper::perPageItem():$request->perPag;

        $skip = ($current_page == 1) ? 0 : (int)($current_page - 1) * $perPage;
        $data_count = $data_query->count();
        $data_list = $data_query->skip($skip)->take($perPage)->get();

        $res = [
            'data_list' => $data_list,
            'group_name' => $group_name,
            'group_id' => $request->group_id,
            'current_page' => $current_page,
            'total_records' => $data_count,
            'total_page' => ceil((int)$data_count / (int)$perPage),
            'per_page' => $perPage,
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }


    // Store Contact Groups

    public function store(Request $request)
    {   
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        //validation check 
        $validator = Validator::make(
            $request->all(),
            [
                'group_name' => 'required',
            ],
            [
                'group_name.required' => 'GROUP_NAME_REQUIRED',
            ]
        );

        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());

        $groupExist = ContactGroup::where('group_name', $request->group_name)->first();
        if (!empty($groupExist))
            return ApiHelper::JSON_RESPONSE(false, [], "GROUP_ALREADY_EXIST");

        $group_data = $request->only(['group_name', 'description']);

        $data = ContactGroup::create($group_data);

        if ($data)
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_CONTACT_GROUP_ADD');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_CONTACT_GROUP_ADD');
    }

    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        $data_list = ContactGroup::find($request->group_id);
        return ApiHelper::JSON_RESPONSE(true, $data_list, '');
    }

    public function update(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        //validation check 
        $validator = Validator::make(
            $request->all(),
            [
                'group_name' => 'required',
            ],
            [
                'group_name.required' => 'GROUP_NAME_REQUIRED',
            ]
        );

        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());

        $groupExist = ContactGroup::where('group_name', $request->group_name)->first();
        if (!empty($groupExist))
            return ApiHelper::JSON_RESPONSE(false, [], "GROUP_ALREADY_EXIST");

        $group_data = $request->only(['group_name', 'description']);

        $data = ContactGroup::where('id', $request->group_id)->update($group_data);

        if ($data)
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_CONTACT_GROUP_UPDATE');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_CONTACT_GROUP_UPDATE');
    }


    public function destroy(Request $request)
    {
        $api_token = $request->api_token;

        $status = ContactGroup::where('id', $request->group_id)->delete();
                ContactToGroup::where('group_id', $request->group_id)->delete();

        if ($status) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_CONTACT_GROUP_DELETE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_CONTACT_GROUP_DELETE');
        }
    }

    public function changeStatus(Request $request)
    {

        $api_token = $request->api_token;
        $id = $request->group_id;
        $sub_data = ContactGroup::find($id);
        $sub_data->status = ($sub_data->status == 0) ? 1 : 0;
        $sub_data->save();

        return ApiHelper::JSON_RESPONSE(true, $sub_data, 'SUCCESS_STATUS_UPDATE');
    }


    public function contactImport(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }


        $group_data = ContactGroup::all();

        $data['group_data'] = $group_data;


        return ApiHelper::JSON_RESPONSE(true, $data, '');
    }


    // Import Exel File of contacts

    public function contactImportUpload(Request $request)
    {   
        // Validate user page access
        $api_token = $request->api_token;

        $import_file = $request->file('import_file');

        //validation check 
        $validator = Validator::make(
            $request->all(),
            [   
                'contact_group' => 'required',
                'import_file' => 'required|mimes:xls,xlsx,csv'
            ],
            [
                'contact_group.required' => 'PLEASE_SELECT_CONTACT_GROUP',
                'import_file.required' => 'PLEASE_UPLOAD_FILE',
                'import_file.mimes' => 'PLEASE_UPLOAD_VALID_FILE',
            ]
        );

        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE('validation', [], $validator->messages());

       
        if (!empty($import_file)) {
            Excel::import(new ContactGroupImport($request->contact_group), $request->file('import_file'));

            return ApiHelper::JSON_RESPONSE('true', [], 'SUCCESS_CONTACT_GROUP_IMPORT');
        }
    }
}
