<?php

namespace Modules\Marketing\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Request;
use ApiHelper;
use Modules\Marketing\Models\ContactToGroup;
use Modules\Marketing\Models\ContactGroup;
use Modules\Marketing\Models\MarketingContact;
use Modules\Marketing\Models\ContactNewsLetter;
use App\Models\Country;
use DateTime;
use Modules\CRM\Models\CRMCustomer;
use Modules\CRM\Models\CRMLead;
use Modules\CRM\Models\CRMLeadContact;
use Modules\CRM\Models\CRMLeadSource;
use Modules\CRM\Models\CRMQuotation;
use Modules\CRM\Models\Enquiry;
use Modules\Ecommerce\Models\Order;
use Modules\Marketing\Models\Campaign;
use Modules\Marketing\Models\CampaignEmail;

class ContactListController extends Controller
{
    public $page = 'contact';
    public $pageview = 'view';
    public $pageadd = 'add';
    public $pagestatus = 'remove';
    public $pageupdate = 'update';

    
    public function create()
    {
        $countrydata = Country::all();
        $group_data = ContactGroup::all();
        $data = [
            'country_data' => $countrydata,
            'group_data' => $group_data,
        ];

        if ($data)
            return ApiHelper::JSON_RESPONSE(true, $data, '');
        else
            return ApiHelper::JSON_RESPONSE(false, [], '');
    }

    public function store(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageadd))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        //validation check 
        $validator = Validator::make(
            $request->all(),
            [
                'contact_name' => 'required',
                'contact_email' => 'required|email',
                'countries_id' => 'required',
            ],
            [
                'contact_name.required' => 'CONTACT_NAME_REQUIRED',
                'contact_email.required' => 'CONTACT_EMAIL_REQUIRED',
                'contact_email.email' => 'ENTER_VALID_EMAIL',
                'countries_id.required' => 'COUNTRY_REQUIRED',
            ]
        );
        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());

        $contact_data =  MarketingContact::create([
            'contact_name' => $request->contact_name,
            'contact_email' => $request->contact_email,
            'company' => $request->company,
            'website' => $request->website,
            'countries_id' =>  $request->countries_id,
            'phone' =>  $request->phone,
            'address' => $request->address,

        ]);

        if (!empty($contact_data)) {
            $contact_group = ContactToGroup::create([
                'group_id' => $request->id,
                'contact_id' => $contact_data->id,
            ]);
        }

        $data = [
            'contact_data' => $contact_data,
            'contact_group' => $contact_group,
        ];

        // $contactNews =  ContactNewsLetter::create([
        //     'contact_id' => $contact_data->id
        // ]);

        if ($data)
            return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_CONTACT_ADD');
        else
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_CONTACT_ADD');
    }

    public function edit(Request $request)
    {
        $api_token = $request->api_token;
        $data_list = MarketingContact::with('contact')->where('id', $request->id)->first();

        $countrydata = Country::all();
        $group_data = ContactGroup::all();


        //   return ApiHelper::JSON_RESPONSE(true,$data_list->contact,'');
        if (!empty($data_list->contact))

            $data_list->contact = $data_list->contact->group_id;

        $res = [
            'data_list' => $data_list,
            'countrydata' => $countrydata,
            'group_data' => $group_data,
        ];


        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }

    public function update(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageupdate)) {
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');
        }

        //validation check 
        $validator = Validator::make(
            $request->all(),
            [
                'contact_name' => 'required',
                'contact_email' => 'required|email',
                'countries_id' => 'required',
            ],
            [
                'contact_name.required' => 'CONTACT_NAME_REQUIRED',
                'contact_email.required' => 'CONTACT_EMAIL_REQUIRED',
                'contact_email.email' => 'ENTER_VALID_EMAIL',
                'countries_id.required' => 'COUNTRY_REQUIRED',
            ]
        );
        if ($validator->fails())
            return ApiHelper::JSON_RESPONSE(false, [], $validator->messages());

        $id = $request->id;

        $data = MarketingContact::where('id', $id)->update([
            'contact_name' => $request->contact_name,
            'contact_email' => $request->contact_email,
            'company' => $request->company,
            'website' => $request->website,
            'countries_id' =>  $request->countries_id,
            'phone' =>  $request->phone,
            'address' => $request->address,

        ]);

        $contact_details = MarketingContact::find($id);
        if (!empty($contact_details)) {
            ContactToGroup::updateOrCreate(
                [
                    'contact_id' => $contact_details->id,
                ],
                [
                    'group_id' => $request->group_id,
                ]
            );
        }

        // $contactNews =  ContactNewsLetter::where('contact_id', $contact_details->id)->update([
        //     'contact_id' => $contact_details->id,
        // ]);

    
        return ApiHelper::JSON_RESPONSE(true, $data, 'SUCCESS_CONTACT_UPDATE');
      
    }

    public function changeStatus(Request $request)
    {

        $api_token = $request->api_token;
        $template_id = $request->template_id;
        $sub_data = ContactToGroup::find($template_id);
        $sub_data->status = ($sub_data->status == 0) ? 1 : 0;
        $sub_data->save();

        return ApiHelper::JSON_RESPONSE(true, $sub_data, 'SUCCESS_STATUS_UPDATE');
    }

    

    public function import_file(Request $request)
    {
        $dataList = ApiHelper::read_csv_data($request->fileInfo, "csv/Contact");
        foreach ($dataList as $key => $value) {

            // $details = $value[0];
            // return ApiHelper::JSON_RESPONSE(true, $details, 'SUCCESS_CONTACT_IMPORTED');

            if (isset($value)) {

                $contact_name = isset($value[0]) ? $value[0] : 0;
                $contact_email = isset($value[1]) ? $value[1] : 0;
                $company = isset($value[2]) ? $value[2] : 0;
                $website = isset($value[3]) ? $value[3] : 0;
                $phone = isset($value[4]) ? $value[4] : 0;
                $address = isset($value[5]) ? $value[5] : 0;

                $newsletter_data =  MarketingContact::where('contact_email', $contact_email)->first();

                if (empty($newsletter_data)) {
                    $data = [
                        'contact_name' => $contact_name,
                        'contact_email' => $contact_email,
                        'company' => $company,
                        'website' => $website,
                        'phone' => $phone,
                        'address' => $address,
                    ];
                    $newsletter = MarketingContact::create($data);

                    $Userdata = [

                        'group_id' => $request->group_id,
                        'contact_id' => $newsletter->id,
                    ];

                    $userCreate = ContactToGroup::create($Userdata);

                    $contactNews = [
                        'contact_id' => $newsletter->id,
                    ];

                    // $contact = ContactNewsLetter::create($contactNews);
                }
            }
        }

        return ApiHelper::JSON_RESPONSE(true, $dataList, 'SUCCESS_CONTACT_IMPORTED');
    }


    public function destroy(Request $request)
    {
        $contact_id = $request->contact_id;
     
        // $data=[
        //     'contact_id'=>$contact_id,
        // ];
        // return ApiHelper::JSON_RESPONSE(true,$data, 'SUCCESS_CONTACT_DELETE');

        $contactData = MarketingContact::find($contact_id);

        $status = 0;

        if (!empty($contactData)) {
            $status = $contactData->contact()->delete();
            $contactData->delete();
        }

        if ($status) {
            return ApiHelper::JSON_RESPONSE(true, [], 'SUCCESS_CONTACT_DELETE');
        } else {
            return ApiHelper::JSON_RESPONSE(false, [], 'ERROR_CONTACT_DELETE');
        }
    }


    // Soucre to contact

    public function sourceContactList(Request $request)
    {
        // Validate user page access
        $api_token = $request->api_token;
        $source=$request->source;
        $subsource=$request->subsource;
        $approvalStatus= $request->approvalStatus;
        $subsStatus= $request->subsStatus;
        $emailStatus= $request->emailStatus;
        $sourceObject='';
        $data_query='';
   
        $campDetails='';
     

        if (!ApiHelper::is_page_access($api_token, $this->page, $this->pageview))
            return ApiHelper::JSON_RESPONSE(false, [], 'PAGE_ACCESS_DENIED');

        $sortBY = $request->sortBy; 
        $ASCTYPE = $request->orderBY;
        $search = $request->search;
        
        $primary_key='';

        $current_page = !empty($request->page) ? $request->page : 1;
        $perPage = !empty($request->perPage) ? (int)$request->perPage : ApiHelper::perPageItem();
        
        if($source=="customer")
        {   
            if(!empty($subsource) && in_array($subsource,['enquiry','order','quotation'])){
                if($subsource=="enquiry")
                {
                    $ids=array_unique(Enquiry::pluck('customer_id')->toArray());
                    $data_query=CRMCustomer::whereIn('customer_id',$ids);
                }
                elseif($subsource=="quotation")
                {   
                    $ids=array_unique(CRMQuotation::pluck('customer_id')->toArray());
                    $data_query=CRMCustomer::whereIn('customer_id',$ids);
                }
                else
                {
                    $ids=array_unique(Order::pluck('customer_id')->toArray());
                    $data_query=CRMCustomer::whereIn('customer_id',$ids);
                }
            }
            else
            {
                $data_query=CRMCustomer::query();
            }

            if (!empty($search)) {
                $data_query = $data_query->where("first_name", "LIKE", "%{$search}%")
                ->orWhere("email", "LIKE", "%{$search}%");
            }

            $primary_key='customer_id';
            $sourceObject='';

            $campData=Campaign::withCount('EmailCount')->where(['source'=>1,'status'=>1])->get();
            
            $campDetails=$campData;

        }
        elseif($source=="lead")
        {    
            if(!empty($subsource))
            $data_query=CRMLead::where('source_id',$subsource);
            else
            $data_query=CRMLead::query();

            if (!empty($search)) {
                $data_query = $data_query->where("contact_name", "LIKE", "%{$search}%")
                ->orWhere("contact_email", "LIKE", "%{$search}%")->orWhere("phone", "LIKE", "%{$search}%");
            }
            $primary_key='lead_id';
            $sourceObject=CRMLeadSource::where('status',1)->get();

            $campData=Campaign::withCount('EmailCount')->where('source',2)->where('status',1)->get();
           
            $campDetails=$campData;

            
        }
        else // Imported
        {
            if(!empty($subsource))
                 $data_query = ContactToGroup::with('group_details', 'contact_details')->where('group_id',$subsource);
            else
                $data_query = ContactToGroup::with('group_details', 'contact_details');

            if (!empty($search)) {
                $data_query = $data_query->whereHas('contact_details', function ($data_query) use ($search) {
                $data_query->where("contact_name", "LIKE", "%{$search}%")->orWhere("contact_email", "LIKE", "%{$search}%");
              });
            } 

            $primary_key='id';
            $sourceObject=ContactGroup::where('status',1)->get();
            
            $campData=Campaign::withCount('EmailCount')->where('source',3)->where('status',1)->get();
           
            $campDetails=$campData;
        }
        

        // Add Date Filter

        if ($request->has('start_date')) {
            if ($request->start_date != NULL) {
                $myDateTime = DateTime::createFromFormat('Y-m-d', $request->start_date);
                $start_date = $myDateTime->format('Y-m-d');

                $data_query = $data_query->whereDate('created_at', '>=', $start_date);
            }
        }

        /* Add End Date Filter  */
        if ($request->has('end_date')) {
            if ($request->end_date != NULL) {
                $myDateTime = DateTime::createFromFormat('Y-m-d', $request->end_date);
                $end_date = $myDateTime->format('Y-m-d');

                $data_query = $data_query->whereDate('created_at', '<=', $end_date);
            }
        }

        // Add Sorting      
        
        if (!empty($sortBY) && !empty($ASCTYPE)) {
            $data_query = $data_query->orderBy($sortBY, $ASCTYPE);
        } else {
            $data_query = $data_query->orderBy($primary_key, 'DESC');
        }
      

        // Work of pagination  

        $skip = ($current_page == 1) ? 0 : (int) ($current_page - 1) * $perPage;

        $total_count = $data_query->count();

        if ($total_count == 0) {
            $data_list = $data_query->get();
        } else {
            $data_list = $data_query->skip($skip)->take($perPage)->get();
        }
        
        $data_list = $data_list->map(function ($data) use($source) {
            $source_id=0;
            $source_type='';

           if($source=="customer"){

            $source_id=$data->customer_id;
            $source_type=1;

            $data->c_name=$data->first_name.' '.$data->last_name;
            $data->c_email=$data->email;
            $data->c_id=$data->customer_id;
            
           }
           elseif($source=="lead"){
            $source_id=$data->lead_id;  
            $source_type=2;

            $data->c_name=$data->contact_name ?? '';
            $data->c_email=$data->contact_email ?? '';
            $data->c_id=$data->lead_id;

           }
           else{
                if(!empty($data->contact_details)){
                    $source_id=$data->contact_details->id; 
                    $source_type=3;

                    $data->c_name=$data->contact_details->contact_name;
                    $data->c_email=$data->contact_details->contact_email;
                    $data->c_id=$data->contact_details->id;
                }
           }

           $contactNewsLetter=ContactNewsLetter::where(['source'=>$source_type,'source_id'=>$source_id])->first();

           if(!empty($contactNewsLetter))
           {
                $campMail=CampaignEmail::with('mailtracker','campaignDetail')->where('newsletter_id',$contactNewsLetter->newsletter_id)->get();
                $contactNewsLetter['campMailData']=$campMail;
                $data['contactNewsData']=$contactNewsLetter;
           }
           else
           $data['contactNewsData']=null;

           return $data;
        });
    
        $group_name = '';
               
        $filtered = $data_list->filter(function ($value, $key) use($approvalStatus,$subsStatus,$emailStatus) {

            $return_stat = false;
            if(!empty($value->contactNewsData) )
            {
                $aproval_exist = $email_exist = $subs_exist = 0;
                
                if (isset($approvalStatus)){
                    if($value->contactNewsData->approval_status == $approvalStatus) 
                    $aproval_exist = 1;
                
                } else{
                    $aproval_exist = 1;
                }
               
                if(isset($subsStatus)){
                    if($value->contactNewsData->subscription_status==$subsStatus) 
                    $subs_exist = 1;
                } else{
                    $subs_exist = 1;
                }
                
                if(isset($emailStatus)){
                    if($value->contactNewsData->email_status==$emailStatus) 
                    $email_exist = 1;
                } else{
                    $email_exist = 1;
                }

                if($aproval_exist && $email_exist && $subs_exist ){
                    return true;
                } else{
                    return false;
                }
        
            } else if( isset($approvalStatus) || isset($subsStatus) || isset($emailStatus)){
                return false;
            } else{
                return true;
            }

        });

        $data_list=$filtered->all();
        
        $res = [
            'data_list' => $data_list,
            'source'=>$source,
            'subsource'=>$subsource,
            'group_name' => $group_name,
            'total_page' => ceil((int) $total_count / (int) $perPage),
            'per_page' => $perPage,
            'current_page' => $current_page,
            'total_records' => $total_count,
            'start_date'=>$request->start_date ,
            'end_date'=>$request->end_date ,
            'sourceObject'=>$sourceObject,
            'campDetails'=>$campDetails,
        ];
        return ApiHelper::JSON_RESPONSE(true, $res, '');
    }
}
