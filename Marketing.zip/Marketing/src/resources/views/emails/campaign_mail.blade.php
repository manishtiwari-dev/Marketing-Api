@php
$htmlMessage = '';
if(!empty($template)){

    $find = [
        '[CUSTOMER_NAME]',
        '[WEB_LINK]',
        '[LOGO]',
        '[FOOTER_LOGO]',
        '[FAVICON_LOGO]',
        '[CONTACT_MAIL]',
        '[FACEBOOK_URL]',
        '[INSTAGRAM_URL]',
        '[LINKEDIN_URL]',
        '[TWITTER_URL]',
        '[CONTACT_ADDRESS]',
        '[CONTACT_CITY]',
        '[CONTACT_STATE]',
        '[CONTACT_COUNTRY]',
        '[CONTACT_ZIP]',
        '[CONTACT_PHONE]',
       ];

       $replace =array(
            $data['customer_data']->name,
            $data['web_base_url']
        );

        $htmlMessage = str_replace($find, $replace, $template);
        preg_match_all('/<a[^>]+href=([\'"])(?<href>.+?)\1[^>]*>/i', $htmlMessage, $result);

        if (sizeof($result['href'])>0) {
            # Found a link.
            foreach ($result['href'] as $key => $value) {
                $main_url =  $result['href'][$key]; 
                $parseurl = parse_url($main_url,PHP_URL_SCHEME).'://'.parse_url($main_url,PHP_URL_HOST); 
                $base_url = trim($parseurl, '/');
                if($base_url== $data['web_base_url'])
                {   
                    $encoded_url=base64_encode($main_url);
                    $encoded_id=base64_encode($data['customer_data']->camp_email_id);

                    $replace_url=$base_url.'/track-mail-link/'.$encoded_id.'/'.$encoded_url;

                    $htmlMessage = str_replace($main_url,$replace_url,$htmlMessage);
                }
            }
        }
   }

@endphp

<img src="{{$data['web_base_url'].'/mail-images/'.$data['customer_data']->camp_email_id }}" hidden>

{!! $htmlMessage !!}
