<?php
namespace Modules\Marketing\Console\Commands;

use Illuminate\Console\Command;
use Carbon\Carbon;
use Modules\Marketing\Models\Campaign;
use Modules\Marketing\Http\Controllers\MarketingCampaignController;
use App\Models\Super\CronSchedular;
use App\Models\Subscription;
use App\Helper\ApiHelper;

class SendCampaignCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'send-campaign:cron';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'This is for send mail for campaign mail';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {   
        $dt = Carbon::now();
        $today_date=$dt->toDateString();
        $current_time=$dt->toTimeString();

        ApiHelper::essential_config_regenerate('');

        $cronSchedules=CronSchedular::where(['status'=>1,'cron_type'=>1])->where('start_date','<=',$today_date)->get();
        if(sizeof($cronSchedules)>0)
        {
            foreach($cronSchedules as $cronData)
            {
               

                $subscriber_id = $cronData->subscriber_id;
                $data = Subscription::where('subscription_id', $subscriber_id)->first();
                if(!empty($data)){
                    $db_id = $data->db_suffix;
                    if($db_id){
                        ApiHelper::essential_config_regenerate($db_id);

                        $campaigns=Campaign::whereDate('start_date','<=',$today_date)->whereTime('from_time','<=',$current_time)
                        ->whereTime('to_time','>=',$current_time)->get();
                        if(sizeof($campaigns)>0)
                        {
                            foreach($campaigns as $campaignData)
                            {
                                 $campaign_id = $campaignData->id;
                                MarketingCampaignController::sendCampaignMail($campaign_id);
                            }
                        }
                    }
                }
            }
        }
       
    }
}
