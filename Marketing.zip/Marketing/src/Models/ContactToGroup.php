<?php

namespace Modules\Marketing\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\Marketing\Models\ContactGroup;
use Modules\Marketing\Models\MarketingContact;


class ContactToGroup extends Model
{
    use HasFactory;

    protected $primaryKey = "id";

    public $timestamps = false;

    protected $guarded=[
     'id',
    ];
     
    public function getTable()
    {
        return config('dbtable.mkt_contacts_to_groups');
    }

  
    public function group_details(){
        return $this->belongsTo(ContactGroup::class,'group_id' ,'id');
    }


      
    public function contact_details(){
        return $this->belongsTo(MarketingContact::class,'contact_id','id');
    }

}
