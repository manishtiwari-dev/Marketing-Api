<?php

namespace Modules\Marketing\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;


class SenderMail extends Model
{
    use HasFactory;

    // protected $connection='mysql';
    // protected $table = "mkt_sender_email";
    protected $primaryKey = 'id';
    protected $guarded = ['id'];

    public $timestamps = false;

    public function getTable()
    {
        return config('dbtable.mkt_sender_email');
    }
}
