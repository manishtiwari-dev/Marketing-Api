<?php

namespace Modules\Marketing\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\Marketing\Models\ContactToGroup;


class MarketingContact extends Model
{
    use HasFactory;

    protected $primaryKey = "id";

    public $timestamps = false;

    protected $guarded=[
     'id',
    ];
     
    public function getTable()
    {
        return config('dbtable.mkt_contacts');
    }

  
    public function contact(){
        return $this->hasOne(ContactToGroup::class,'contact_id','id');
    }


}
