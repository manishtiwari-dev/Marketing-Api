<?php

namespace Modules\Marketing\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\ContactNewsLetter;
use Modules\Marketing\Models\CampaignTracker;
use Modules\Marketing\Models\Campaign;

class CampaignEmail extends Model
{
    use HasFactory;

    protected $primaryKey = "id";

    public $timestamps = false;

    protected $guarded=[
     'id',
    ];
     
    public function getTable()
    {
        return config('dbtable.mkt_campaign_emails');
    }

    
    public function campaignewsletter()
    {
        return $this->belongsTo(ContactNewsLetter::class, 'newsletter_id', 'newsletter_id');
    }

    public function mailtracker()
    {
        return $this->hasOne(CampaignTracker::class, 'campaign_contact_id', 'id');
    }


    public function campaignDetail()
    {
        return $this->belongsTo(Campaign::class, 'campaign_id', 'id');
    }



}
