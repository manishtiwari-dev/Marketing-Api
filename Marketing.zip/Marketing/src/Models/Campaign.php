<?php

namespace Modules\Marketing\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Modules\Marketing\Models\CampaignEmail;
use Modules\Marketing\Models\MarketingTemplate;

class Campaign extends Model
{
    use HasFactory;

    protected $primaryKey = "id";

    public $timestamps = false;

    protected $guarded=[
     'id',
    ];
     
    public function getTable()
    {
        return config('dbtable.mkt_campaigns');
    }


    public function campaignEmail()
    {
        return $this->hasMany(campaignEmail::class, 'campaign_id', 'id');
    }

    public function EmailCount()
    {
        return $this->hasMany(campaignEmail::class, 'campaign_id', 'id')->where('status',2);
    }


    public function mailtemplate()
    {
        return $this->hasOne(MarketingTemplate::class, 'id', 'template_id');
    }


}
